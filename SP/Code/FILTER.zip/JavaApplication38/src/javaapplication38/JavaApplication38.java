/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication38;

import java.util.ArrayList;

/**
 *
 * @author tho
 */
public class JavaApplication38 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //each of the following arrays contains valid courses for the corresponding grade and trimester
        ArrayList<String> ninefall = new ArrayList<>();
        ArrayList<String> tenfall = new ArrayList<>();
        ArrayList<String> elevenfall = new ArrayList<>();
        ArrayList<String> twelvefall = new ArrayList<>();
        ArrayList<String> ninewinter = new ArrayList<>();
        ArrayList<String> tenwinter = new ArrayList<>();
        ArrayList<String> elevenwinter = new ArrayList<>();
        ArrayList<String> twelvewinter = new ArrayList<>();
        ArrayList<String> ninespring = new ArrayList<>();
        ArrayList<String> tenspring = new ArrayList<>();
        ArrayList<String> elevenspring = new ArrayList<>();
        ArrayList<String> twelvespring = new ArrayList<>();
        ArrayList<String> legal = new ArrayList<>();
        String preq="Ancient Poetry";
       
     
     
        //all Upper School English Courses
        String l1 = "Ancient Poetry";
        String l2 = "Lating American Literature";
        String l3 = "Medieval Literature";
        String l4 = "Shakespeare";
        String l5 = "British Literature";
        String l6 = "Modern European Literature";
        String l7 = "Modern Asain Literature";
        String l8 = "Modern African Literature";
        String l9 = "Middle Eastern Literature";
        String l10 = "American Literature";
        String l11 = "Emotion and Motive in Literature";
        String l12 = "Critical Practices";
        String l13 = "1950s Literature";
        String l14 = "Post Modern Theory";
        //all Uper School History Courses
        String h1 = "Pre-History";
        String h2 = "Lating American History";
        String h3 = "Medieval HIstory";
        String h4 = "Renaissance History";
        String h5 = "Revolutions in Thought";
        String h6 = "Modern European History";
        String h7 = "Modern Asain History";
        String h8 = "Modern African History";
        String h9 = "Middle Eastern History";
        String h10 = "International Relations";
        String h11 = "The Economics of Development";
        String h12 = "Comparative Government";
        String h13 = "Democratic Theories";
        String h14 = "Public Policy";

        //Adding to array
        //nineth grade
        ninefall.add(0, l1);
        ninefall.add(1, l2);
        ninefall.add(2, l3);

        ninewinter.add(0, l4);
        ninewinter.add(1, l5);
        ninewinter.add(2, l6);

        ninespring.add(0, l7);
        ninespring.add(1, l8);
        ninespring.add(2, l9);

        //tenth grade
        tenfall.add(0, l1);
        tenfall.add(1, l2);
        tenfall.add(2, l3);

        tenwinter.add(0, l4);
        tenwinter.add(1, l5);
        tenwinter.add(2, l6);

        tenspring.add(0, l7);
        tenspring.add(1, l8);
        tenspring.add(2, l9);

        //elventh grade 
        elevenfall.add(0, l10);

        elevenwinter.add(0, l10);

        elevenspring.add(0, l10);

        //12th grade
        twelvefall.add(0, l11);
        twelvefall.add(1, l12);
        twelvefall.add(2, l13);
        twelvefall.add(3, l14);

        twelvewinter.add(0, l11);
        twelvewinter.add(1, l12);
        twelvewinter.add(2, l13);
        twelvewinter.add(3, l14);

        twelvespring.add(0, l1);
        twelvespring.add(1, l12);
        twelvespring.add(2, l13);
        twelvespring.add(3, l14);
        
        
        //=-----------------------------------------------
        
        ninefall.add(3, h1);
        ninefall.add(4, h2);
        ninefall.add(5, h3);

        ninewinter.add(3, h4);
        ninewinter.add(4, h5);
        ninewinter.add(5, h6);

        ninespring.add(3, h7);
        ninespring.add(4, h8);
        ninespring.add(5, h9);

        //tenth grade
        tenfall.add(3, h1);
        tenfall.add(4, h2);
        tenfall.add(5, h3);

        tenwinter.add(3, h4);
        tenwinter.add(4, h5);
        tenwinter.add(5, h6);

        tenspring.add(3, h7);
        tenspring.add(4, h8);
        tenspring.add(5, h9);

        //elventh grade 
        elevenfall.add(1, h10);

        elevenwinter.add(1, h10);

        elevenspring.add(1, h10);

        //12th grade
        twelvefall.add(4, h11);
        twelvefall.add(5, h12);
        twelvefall.add(6, h13);
        twelvefall.add(7, h14);

        twelvewinter.add(4, h11);
        twelvewinter.add(5, h12);
        twelvewinter.add(6, h13);
        twelvewinter.add(7, h14);

        twelvespring.add(4, h1);
        twelvespring.add(5, h12);
        twelvespring.add(6, h13);
        twelvespring.add(7, h14);

       for(int i = 0; i < ninefall.size(); i++){
        if (ninefall.get(i).contains(preq)){
           ninefall.remove(i);
       }
        System.out.println(ninefall.get(i));
        
            
       }
       
// TODO code application logic here
    }

}
