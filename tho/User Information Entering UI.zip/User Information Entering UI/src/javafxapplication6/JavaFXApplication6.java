/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxapplication6;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 *
 * @author tho
 */
public class JavaFXApplication6 extends Application {

    @Override
    public void start(Stage primaryStage) {
        //begin code for login button 
        Button loginbtn = new Button();
        loginbtn.setText("Login");
        //end code for login button
        //begin code for name lable 
        Label namelbl = new Label("Name:");

        Pane root = new Pane();
        
        root.getChildren().add(loginbtn);
        loginbtn.setLayoutX(150);
        loginbtn.setLayoutY(180);
        
    
        root.getChildren().add(namelbl);
        namelbl.setLayoutX(150);
        namelbl.setLayoutY(125);
        

        Scene scene = new Scene(root, 400, 305);

        primaryStage.setTitle("Schedule Prototype");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

}
