/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxapplication6;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 *
 * @author tho
 */
public class JavaFXApplication6 extends Application {

    @Override
    public void start(Stage primaryStage) {
        //begin code for login button 

        //end code for login button
        //begin code for name lable 
       

        Pane root = new Pane();

        Button loginbtn = new Button();
        loginbtn.setText("Continue...");
        root.getChildren().add(loginbtn);
        loginbtn.setLayoutX(150);
        loginbtn.setLayoutY(180);
        loginbtn.setStyle("-fx-font: 16 arial; -fx-base: LIGHTGREY;");

        Label namelbl = new Label("Name:");
        root.getChildren().add(namelbl);
        namelbl.setLayoutX(100);
        namelbl.setLayoutY(75);
        namelbl.setStyle("-fx-font: 16 arial;");
        
        TextField nametf = new TextField ("");
        root.getChildren().add(nametf);
        nametf.setPrefWidth(150);
        nametf.setPrefHeight(5);
        nametf.setLayoutX(150);
        nametf.setLayoutY(70);
        nametf.setStyle("-fx-font: 16 arial;");
        
        Label gradelbl = new Label("Grade:");
        root.getChildren().add(gradelbl);
        gradelbl.setLayoutX(100);
        gradelbl.setLayoutY(120);
        gradelbl.setStyle("-fx-font: 16 arial;");
        
        
        TextField gradetf = new TextField ("");
        root.getChildren().add(gradetf);
        gradetf.setPrefWidth(150);
        gradetf.setPrefHeight(5);
        gradetf.setLayoutX(150);
        gradetf.setLayoutY(115);
        gradetf.setStyle("-fx-font: 16 arial;");

        Scene scene = new Scene(root, 400, 300);

        primaryStage.setTitle("Schedule Prototype");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

}
